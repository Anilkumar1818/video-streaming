import java.util.Random;

class Player {
    int health, strength, attack;

    public Player(int health, int strength, int attack) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
    }
}

public class MagicalArena {
    Random random = new Random();

    public int rollDice() {
        return random.nextInt(6) + 1; // Dice roll between 1 and 6
    }

    public void fight(Player playerA, Player playerB) {
        // Determine the initial attacker and defender
        Player attacker = playerA.health < playerB.health ? playerA : playerB;
        Player defender = playerA == attacker ? playerB : playerA;

        while (playerA.health > 0 && playerB.health > 0) {
            int attackRoll = rollDice();
            int defendRoll = rollDice();
            int attackDamage = attacker.attack * attackRoll;
            int defendDamage = defender.strength * defendRoll;
            int damageToDefender = Math.max(0, attackDamage - defendDamage);

            defender.health -= damageToDefender;
            System.out.println("Attacker deals " + attackDamage + " damage, Defender blocks " + defendDamage + " damage, " + defender.health + " health remaining for defender.");

            // Swap roles
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        if (playerA.health <= 0) {
            System.out.println("Player B wins!");
        } else {
            System.out.println("Player A wins!");
        }
    }

    public static void main(String[] args) {
        Player playerA = new Player(50, 5, 10);
        Player playerB = new Player(100, 10, 5);
        new MagicalArena().fight(playerA, playerB);
    }
}

