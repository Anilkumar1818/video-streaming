import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MagicalArenaTest {

    @Test
    public void testFight() {
        Player playerA = new Player(50, 5, 10);
        Player playerB = new Player(100, 10, 5);
        MagicalArena arena = new MagicalArena();

        arena.fight(playerA, playerB);

        // Check that one player's health is 0 or below after the fight
        assertTrue(playerA.health <= 0 || playerB.health <= 0);
    }

    @Test
    public void testRollDice() {
        MagicalArena arena = new MagicalArena();
        int roll = arena.rollDice();

        assertTrue(roll >= 1 && roll <= 6);
    }
}

